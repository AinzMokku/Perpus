-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.37-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5293
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for db_perpus
CREATE DATABASE IF NOT EXISTS `db_perpus` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_perpus`;

-- Dumping structure for table db_perpus.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_perpus.migrations: ~6 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_02_07_061336_create_admins_table', 2),
	(4, '2019_02_08_135645_create_writers_table', 2),
	(5, '2019_02_08_141828_create_writers_table', 3),
	(6, '2019_02_08_142122_create_admins_table', 3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table db_perpus.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_perpus.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_anggota
CREATE TABLE IF NOT EXISTS `tb_anggota` (
  `kd_anggota` int(11) NOT NULL AUTO_INCREMENT,
  `no_anggota` varchar(50) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `tempat` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jk` int(1) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `kota` varchar(50) DEFAULT NULL,
  `telp` varchar(12) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `foto` text,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kd_anggota`),
  UNIQUE KEY `no_anggota` (`no_anggota`),
  KEY `jk` (`jk`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_anggota: ~5 rows (approximately)
/*!40000 ALTER TABLE `tb_anggota` DISABLE KEYS */;
INSERT INTO `tb_anggota` (`kd_anggota`, `no_anggota`, `nama`, `tempat`, `tgl_lahir`, `jk`, `alamat`, `kota`, `telp`, `email`, `user_name`, `user_password`, `foto`, `status`) VALUES
	(4, '2019010004', 'Imam', 'Ngawi', '1970-01-01', 1, 'hai', 'Ngawi', '085134165458', 'Imam@gmail.com', 'Imam', '202cb962ac59075b964b07152d234b70', '02-2019-user8-128x128.jpg', '3'),
	(6, '2019020006', 'Abdul', 'Malang', '1995-05-05', 1, 'Jl Anggur no 40', 'Malang', '082565656565', 'Abdul@gmail.com', 'Abdul', '428a78b4fee47253898d7918c0a09160', NULL, '3'),
	(7, '2019020007', 'zikma', 'Malang', '1970-01-01', 1, 'Jl Monday', 'Malang', '085614253786', 'Zikma@gmail.com', 'zikma', '0ce0b0b82ec4d0e33a98aaef8c3c75a6', NULL, '1'),
	(8, '2019020008', 'Louvre', 'malang', '2000-01-01', 1, 'Ygs', 'malang', '986348763', 'mamber1@a.com', 'Louvre', '5f4c6b0a4c5edb6a99ebb7e4e9f57dd0', NULL, '1'),
	(9, '2019020009', 'Ogre', 'Toyko', '1970-01-01', 1, 'Legenda', 'Tokyo', '6666666666', 'Tokyo@a.com', 'Ogre', 'e46e3b1313cfb825cb7856e2fdc792e4', NULL, '3');
/*!40000 ALTER TABLE `tb_anggota` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_buku
CREATE TABLE IF NOT EXISTS `tb_buku` (
  `kd_buku` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `kd_pengarang` int(11) NOT NULL,
  `kd_penerbit` int(11) NOT NULL,
  `tempat_terbit` varchar(50) DEFAULT NULL,
  `tahun_terbit` varchar(50) DEFAULT NULL,
  `kd_kategori` int(11) NOT NULL,
  `halaman` varchar(50) DEFAULT NULL,
  `edisi` varchar(50) DEFAULT NULL,
  `ISBN` varchar(50) DEFAULT NULL,
  `cover` longtext,
  PRIMARY KEY (`kd_buku`),
  KEY `Kd_pengarang` (`kd_pengarang`),
  KEY `Kd_penerbit` (`kd_penerbit`),
  KEY `kd_kategori` (`kd_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_buku: ~1 rows (approximately)
/*!40000 ALTER TABLE `tb_buku` DISABLE KEYS */;
INSERT INTO `tb_buku` (`kd_buku`, `judul`, `kd_pengarang`, `kd_penerbit`, `tempat_terbit`, `tahun_terbit`, `kd_kategori`, `halaman`, `edisi`, `ISBN`, `cover`) VALUES
	(1, 'Fakta unik sains', 1, 1, 'malang', '2014', 2, '260', NULL, NULL, '02-2019-fakta unik sains.jpg'),
	(2, 'This Is Why I Need You', 4, 5, 'Indonesia', '2019', 3, '604', '-', '9769797945770', '02-2019-02-2019-This Is Why I Need You.jpg'),
	(3, 'v', 3, 5, 'madiun', '20129', 2, '120', 'limitied', '80983203', NULL);
/*!40000 ALTER TABLE `tb_buku` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_kategori
CREATE TABLE IF NOT EXISTS `tb_kategori` (
  `kd_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) DEFAULT NULL,
  `singkatan` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`kd_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_kategori: ~2 rows (approximately)
/*!40000 ALTER TABLE `tb_kategori` DISABLE KEYS */;
INSERT INTO `tb_kategori` (`kd_kategori`, `nama_kategori`, `singkatan`) VALUES
	(1, 'Komputer', 'Kom'),
	(2, 'Sains', 'Sai'),
	(3, 'Fiksi', 'Fik');
/*!40000 ALTER TABLE `tb_kategori` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_koleksi_buku
CREATE TABLE IF NOT EXISTS `tb_koleksi_buku` (
  `kd_koleksi` int(11) NOT NULL AUTO_INCREMENT,
  `no_induk_buku` varchar(50) NOT NULL,
  `kd_buku` int(11) NOT NULL,
  `kd_user` int(11) NOT NULL,
  `tgl_pengadaan` date DEFAULT NULL,
  `akses` varchar(50) DEFAULT NULL,
  `kd_rak` int(11) NOT NULL,
  `sumber` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`kd_koleksi`),
  KEY `no_induk_buku` (`no_induk_buku`),
  KEY `kd_buku` (`kd_buku`),
  KEY `kd_user` (`kd_user`),
  KEY `kd_rak` (`kd_rak`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_koleksi_buku: ~28 rows (approximately)
/*!40000 ALTER TABLE `tb_koleksi_buku` DISABLE KEYS */;
INSERT INTO `tb_koleksi_buku` (`kd_koleksi`, `no_induk_buku`, `kd_buku`, `kd_user`, `tgl_pengadaan`, `akses`, `kd_rak`, `sumber`, `status`) VALUES
	(1, 'B-0001-Sai-000001', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 1),
	(2, 'B-0001-Sai-000002', 1, 1, '2014-06-04', 'Boleh Dipinjam', 1, 'BukuKita.com', 0),
	(3, 'B-0001-Sai-000003', 1, 1, '2014-06-04', 'Boleh Dipinjam', 1, 'BukuKita.com', 0),
	(4, 'B-0001-Sai-000004', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 3),
	(5, 'B-0001-Sai-000005', 1, 1, '2014-06-04', 'Boleh Dipinjam', 1, 'BukuKita.com', 0),
	(6, 'B-0001-Sai-000006', 1, 1, '2014-06-04', 'Boleh Dipinjam', 1, 'BukuKita.com', 0),
	(7, 'B-0002-Fik-000007', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 0),
	(8, 'B-0002-Fik-000008', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 0),
	(9, 'B-0002-Fik-000009', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 3),
	(10, 'B-0002-Fik-000010', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 1),
	(11, 'B-0002-Fik-000011', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 0),
	(12, 'B-0002-Fik-000012', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 0),
	(13, 'B-0002-Fik-000013', 2, 1, '2014-06-04', 'Boleh Dipinjam', 2, 'BukuKita.com', 0),
	(14, 'B-0002-Fik-000014', 3, 1, '2014-06-04', 'Boleh Dipinjam', 3, 'BukuKita.com', 2),
	(15, 'B-0003-Sai-000015', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(16, 'B-0003-Sai-000016', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(17, 'B-0003-Sai-000017', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(18, 'B-0003-Sai-000018', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(19, 'B-0003-Sai-000019', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(20, 'B-0003-Sai-000020', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(21, 'B-0003-Sai-000021', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(22, 'B-0003-Sai-000022', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(23, 'B-0003-Sai-000023', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(24, 'B-0003-Sai-000024', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(25, 'B-0003-Sai-000025', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(26, 'B-0003-Sai-000026', 3, 1, '2004-06-08', 'Boleh Dipinjam', 3, 'link.com', 0),
	(27, 'B-0002-Fik-000027', 2, 1, '2018-12-31', 'Boleh Dipinjam', 1, 'kl', 2),
	(28, 'B-0002-Fik-000028', 2, 1, '2018-12-31', 'Boleh Dipinjam', 2, 'kl', 0);
/*!40000 ALTER TABLE `tb_koleksi_buku` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_peminjaman
CREATE TABLE IF NOT EXISTS `tb_peminjaman` (
  `kd_pinjam` int(11) NOT NULL AUTO_INCREMENT,
  `no_pinjam` varchar(50) DEFAULT NULL,
  `tgl_pinjam` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `no_induk_buku` varchar(50) DEFAULT NULL,
  `no_anggota` varchar(50) DEFAULT NULL,
  `denda` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  PRIMARY KEY (`kd_pinjam`),
  KEY `kd_anggota` (`no_anggota`),
  KEY `denda` (`denda`),
  KEY `status` (`status`),
  KEY `no_induk_buku` (`no_induk_buku`),
  KEY `no_pinjam` (`no_pinjam`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_peminjaman: ~12 rows (approximately)
/*!40000 ALTER TABLE `tb_peminjaman` DISABLE KEYS */;
INSERT INTO `tb_peminjaman` (`kd_pinjam`, `no_pinjam`, `tgl_pinjam`, `tgl_kembali`, `no_induk_buku`, `no_anggota`, `denda`, `status`, `tgl_pengembalian`) VALUES
	(1, 'P000001', '2019-01-30', '2019-02-02', 'B-0001-Sai-000001', '2019010001', 2000, 1, NULL),
	(2, 'P000002', '2019-01-30', '2019-02-02', 'B-0001-Sai-000001', '2019010001', 2000, 1, NULL),
	(3, 'P000003', '2019-01-30', '2019-02-02', 'B-0001-Sai-000002', '2019010001', 2000, 1, NULL),
	(4, 'P000004', '2019-01-31', '2019-02-03', 'B-0001-Sai-000002', '2019010001', 4000, 1, NULL),
	(5, 'P000004', '2019-01-31', '2019-02-03', 'B-0001-Sai-000004', '2019010001', 4000, 1, NULL),
	(6, 'P000004', '2019-01-31', '2019-02-03', 'B-0001-Sai-000005', '2019010001', 4000, 1, NULL),
	(7, 'P000007', '2019-02-04', '2019-02-07', 'B-0001-Sai-000003', '2019020006', 0, 1, NULL),
	(8, 'P000008', '2019-02-04', '2019-02-07', 'B-0001-Sai-000006', '2019020006', 0, 1, NULL),
	(9, 'P000009', '2019-02-04', '2019-02-07', 'B-0001-Sai-000002', '2019010004', 26000, 1, NULL),
	(10, 'P000010', '2019-02-04', '2019-02-07', 'B-0001-Sai-000003', '2019010004', 26000, 1, NULL),
	(11, 'P000011', '2019-02-20', '2019-02-23', 'B-0001-Sai-000005', '2019010004', 0, 1, NULL),
	(12, 'P000012', '2019-02-20', '2019-02-23', 'B-0002-Fik-000010', '2019010004', NULL, 0, NULL);
/*!40000 ALTER TABLE `tb_peminjaman` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_penerbit
CREATE TABLE IF NOT EXISTS `tb_penerbit` (
  `kd_penerbit` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penerbit` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `telp` varchar(12) DEFAULT NULL,
  `kota` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `foto` mediumtext,
  PRIMARY KEY (`kd_penerbit`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_penerbit: ~7 rows (approximately)
/*!40000 ALTER TABLE `tb_penerbit` DISABLE KEYS */;
INSERT INTO `tb_penerbit` (`kd_penerbit`, `nama_penerbit`, `alamat`, `telp`, `kota`, `email`, `foto`) VALUES
	(1, 'nusa creativa', NULL, NULL, NULL, NULL, NULL),
	(2, 'nusa c', NULL, NULL, NULL, NULL, NULL),
	(3, 'penerbit 3', NULL, NULL, NULL, NULL, NULL),
	(4, 'penerbit 4', NULL, NULL, NULL, NULL, NULL),
	(5, 'MEDIAKITA', 'Jl. H. Montong No.57 \r\nJagakarsa Ciganjur', NULL, 'Jakarta Selatan', 'redaksi@mediakita.com', NULL),
	(6, 'aku', 'madiun', NULL, 'madiun', NULL, NULL),
	(7, 'jhasdkja', 'shgfjhs', '6872643', 'sdfgjhs', 'ad@m.com', NULL);
/*!40000 ALTER TABLE `tb_penerbit` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_pengarang
CREATE TABLE IF NOT EXISTS `tb_pengarang` (
  `kd_pengarang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengarang` varchar(50) NOT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telp` varchar(50) DEFAULT NULL,
  `foto` text,
  PRIMARY KEY (`kd_pengarang`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_pengarang: ~2 rows (approximately)
/*!40000 ALTER TABLE `tb_pengarang` DISABLE KEYS */;
INSERT INTO `tb_pengarang` (`kd_pengarang`, `nama_pengarang`, `alamat`, `email`, `telp`, `foto`) VALUES
	(1, 'anjay', NULL, NULL, NULL, NULL),
	(2, 'lol', NULL, NULL, NULL, NULL),
	(3, 'NUSA CREATIVA', NULL, NULL, NULL, NULL),
	(4, 'Brian Khrisna', NULL, NULL, '081910501914', NULL),
	(5, 'jhsjdfhgjs', 'kj', 'asda@a.com', '687264', NULL);
/*!40000 ALTER TABLE `tb_pengarang` ENABLE KEYS */;

-- Dumping structure for table db_perpus.tb_rak
CREATE TABLE IF NOT EXISTS `tb_rak` (
  `kd_rak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rak` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kd_rak`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table db_perpus.tb_rak: ~0 rows (approximately)
/*!40000 ALTER TABLE `tb_rak` DISABLE KEYS */;
INSERT INTO `tb_rak` (`kd_rak`, `nama_rak`) VALUES
	(1, 'komputer dan Informatika'),
	(2, 'Fiksi'),
	(3, 'contoh');
/*!40000 ALTER TABLE `tb_rak` ENABLE KEYS */;

-- Dumping structure for table db_perpus.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telp` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_perpus.users: ~8 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `alamat`, `telp`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `level`, `avatar`) VALUES
	(1, 'Ainz', NULL, NULL, 'Ainz@gmail.com', NULL, '$2y$10$jlkLVEw8oLzOlp.QziTznOd7CSRGPukAk9vqi5JgjzqqyHLiljg12', 'Bwzz0viydzLr3iFHrFYCRmOZfl9yvMGSIX3hHocCUW3JRMk1xkIUeo6JJf4s', '2019-02-06 03:53:08', '2019-02-06 03:53:08', 1, NULL),
	(2, 'laravel', 'madiun', '099999', 'laravel@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', NULL, '2019-02-10 13:53:30', '2019-02-26 11:48:09', 2, NULL),
	(3, 'Woala', 'Olimpus', '069686866', 'mamber@a.com', NULL, '$2y$10$OOhHCeOwifjh1XRI.Lcv5.JH1NkcyHWHawJqoo92AUW5ysfeRwrKm', 'd3pdEPHxCmc6StVydub7EAMm8eymBK3d4kwYjc7YKASjr0vTJnvBp3R3xKkV', '2019-02-11 02:49:52', '2019-02-11 02:49:52', 2, NULL),
	(4, 'Louvre', 'Ygs', 't8778689', 'mamber1@a.com', NULL, '$2y$10$8lKSm5FOeWh1JrSX9vJpau77JXvGEsczBmT8f1caYs20tPseeZQsK', 'wh3AMksx8ywSgobILuqgHF7EgXRgAKE4p1DFU7WYHUqN0bvTRisnhSi2hohd', '2019-02-11 04:20:12', '2019-02-11 04:20:12', 3, NULL),
	(5, 'ksjdhfkj', 'jshfkjhs', 'KJHDFKJHSF', 'JHAS@C.COM', NULL, '$2y$10$QwIQ8c1.PTnyNMEH8AvypuQT0ODV468CdPxeI8S5BQS8gLz4j5Y.u', NULL, '2019-02-20 04:55:11', '2019-02-20 04:55:11', 2, '02-2019-avatar.png'),
	(6, 'ksjdhfkj', 'jshfkjhs', 'KJHDFKJHSF', 'JHAS@C.COM', NULL, '$2y$10$ArZmn5fryRyk1LR9X3M1geT.hZSjT5nGX8E4UZWqMQXM9B5wemney', NULL, '2019-02-20 04:56:09', '2019-02-20 04:56:09', 2, '02-2019-avatar.png'),
	(7, 'ksjdhfkj', 'jshfkjhs', 'KJHDFKJHSF', 'JHAS@C.COM', NULL, '$2y$10$kzktXjL05JDqpSdeN3xtuesJ2Y75Cm/FZtS527hIyy9F88JRgd6mK', NULL, '2019-02-20 04:56:20', '2019-02-20 04:56:20', 2, '02-2019-avatar.png'),
	(8, 'ksjdhfkj', 'jshfkjhs', 'KJHDFKJHSF', 'JHAS@C.COM', NULL, '$2y$10$s5Y2i.8lhQxViiwPz36yte6DDY6EXXwhj9VAWSZ4qWgQ8P5OFQ1jO', NULL, '2019-02-20 04:57:37', '2019-02-20 04:57:37', 2, '02-2019-avatar2.png');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
